
# coding: utf-8

# # 方案优化

# In[1]:


import numpy as np
import xlrd
import xlwt


# In[2]:


# 读取数据
data = xlrd.open_workbook('B2005Table2.xls')
matrix_0=np.zeros((1000, 100))

table = data.sheets()[0]
colnames = table.row_values(0)
row2 = table.row_values(1)
num = row2[2:]   # 100 list, DVD现有数量


# In[3]:


# 用户满意度矩阵
matrix_1 = np.zeros((1000, 100))


# In[4]:


for i in range(2, 102):
    cols = table.col_values(i)
    matrix_cols = np.matrix(cols[2:])
    matrix_1[:,i-2] = matrix_cols

# 对于非0的处理为|x-11|
for i in range(matrix_1.shape[0]):
    for j in range(matrix_1.shape[1]):
        if (matrix_1[i][j]):
            matrix_1[i][j] = abs(matrix_1[i][j] - 11)

matrix_0=matrix_1.copy()
# In[5]:


# 得到用户满意度矩阵
print("用户满意度矩阵:\n", matrix_1.shape)
print(matrix_1)


# In[6]:


all_dvd_needs = np.sum(matrix_1, axis =0)
print(all_dvd_needs)


# In[7]:


# 用户订购矩阵
matrix_2 = np.zeros((1000,100))


# In[8]:


while 1:
    # 找到满意度最高的DVD
    most_satisfied_dvd_index = np.argsort(-all_dvd_needs)[0]
    print("满意度最高的DVD：", most_satisfied_dvd_index)

    # 将最喜欢该DVD的前5个用户满意度清零
    five_most_like_user_index = np.argsort(-matrix_1[:,most_satisfied_dvd_index])[0:1]
    print("最喜欢此DVD的前5个人", five_most_like_user_index)
    for j in five_most_like_user_index:
        matrix_1[j][most_satisfied_dvd_index] = 0
        matrix_2[j][most_satisfied_dvd_index] = 1

    # 如果某一用户订购数量为3时，清空其满意度
    for j in range(1000):
        total_dvd_per_user = np.int(np.sum(matrix_2[j]))
        
        if total_dvd_per_user == 3:
            for k in range(100):
                matrix_1[j][k] = 0

    total_3dvd_users_num = 0            

    # 统计订购数量为3的用户总数
    for j in range(1000):
        total_dvd_per_user = np.int(np.sum(matrix_2[j]))
        if total_dvd_per_user == 3:
            total_3dvd_users_num = total_3dvd_users_num + 1
    print("订购数量为3的用户总数", total_3dvd_users_num)
    if total_3dvd_users_num >= 950:
        break

    # 更新各dvd总满意度
    all_dvd_needs = np.sum(matrix_1, axis =0)

matrix_3=matrix_0*matrix_2


# In[9]:


# 输出结果到excel
workbook = xlwt.Workbook(encoding='utf-8')

#创建sheet
sheet1 = workbook.add_sheet('用户满意度矩阵')
sheet2 = workbook.add_sheet('用户订购情况矩阵')
sheet3 = workbook.add_sheet('用户满意度情况矩阵')
# 写入用户满意度矩阵
for i in range(1000):
    for j in range(100):
        sheet1.write(i, j, matrix_1[i][j])
        
# 写入用户订购情况矩阵
for i in range(1000):
    for j in range(100):
        sheet2.write(i, j, matrix_2[i][j])
# 写入用户订购满意度情况矩阵
for i in range(1000):
    for j in range(100):
        sheet3.write(i, j, matrix_0[i][j])


# In[10]:


workbook.save('dvd_3_hzl.xls')

