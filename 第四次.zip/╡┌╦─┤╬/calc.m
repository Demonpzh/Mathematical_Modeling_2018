function [var_w,tno_rate,w] = calc(m,n,pt,dmin,gzcs,start)
workload=zeros(1,n);
w=zeros(1,20);
solve=zeros(m,4);
tno_num=0;
for i=1:m
    solve(i,1)=start+i;
    solve(i,2)=0;
    solve(i,3)=inf;
    solve(i,4)=0;
    for j=1:n
        if solve(i,3)>dmin(start+i,pt(j))*100
            solve(i,3)=dmin(start+i,pt(j))*100;
            solve(i,2)=pt(j);
        end
    end
    if solve(i,3)>3000
        tno_num=tno_num+1;
    end
end
tno_rate=tno_num/m;
for i=1:n
    for j=1:m
        if solve(j,2)==pt(i)
            w(i)=solve(j,3)*gzcs(j)/1000;
            workload(1,i)=workload(1,i)+w(i);
        end
    end
end
workload=workload;
var_w=std(workload,0,2);